# Relatório em LaTeX

O arquivo `relatorio.tex` segue o template de artigo da SBC em `resources/template-latex/`. Os arquivos `sbc-template.sty` e `sbc.bst` foram copiados para este diretório para permitir compilação independente.

Preencha os campos de autor e instituição antes da entrega. Para gerar o PDF em um ambiente com `pdflatex` e `bibtex` instalados:

```sh
cd relatorio
pdflatex relatorio.tex
bibtex relatorio
pdflatex relatorio.tex
pdflatex relatorio.tex
```

As tabelas foram transcritas dos arquivos `results/<gene>/*.tsv`. A documentação de origem está em `docs/` e `README.md` na raiz do projeto.
